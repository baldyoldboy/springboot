create definer = root@localhost view stu_v_1 as
select `chapter01`.`student`.`sid` AS `sid`, `chapter01`.`student`.`sname` AS `sname`
from `chapter01`.`student`
where (`chapter01`.`student`.`sid` < 20);

