create
    definer = root@localhost procedure p10(IN uage int)
begin
    declare uname varchar(10);
    declare ucourse varchar(20);
    declare u_cursor cursor for select sname,course from student where age<=uage;
    declare exit handler for sqlstate '02000' close u_cursor;
    ##declare exit handler for not found close u_cursor;
    drop table if exists tb_user;
    create table if not exists tb_user(
      id int auto_increment primary key ,
      name varchar(10),
      course varchar(20)
    );

    open u_cursor;
    while true do
        fetch u_cursor into uname,ucourse;
        insert into tb_user values (null,uname,ucourse);
    end while;

    close u_cursor;
end;

