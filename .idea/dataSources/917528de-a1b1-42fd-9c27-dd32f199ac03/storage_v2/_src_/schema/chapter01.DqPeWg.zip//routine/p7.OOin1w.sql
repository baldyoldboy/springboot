create
    definer = root@localhost procedure p7(IN n int)
begin
    declare sum int default 0;
    repeat
        set sum:=sum+n;
        set n:=n-1;
    until n<=0
    end repeat;
    select sum;
end;

