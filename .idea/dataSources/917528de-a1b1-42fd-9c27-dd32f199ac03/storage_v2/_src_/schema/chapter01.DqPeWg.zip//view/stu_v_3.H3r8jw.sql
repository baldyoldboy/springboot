create definer = root@localhost view stu_v_3 as
select `stu_v_2`.`sid` AS `sid`, `stu_v_2`.`sname` AS `sname`
from `chapter01`.`stu_v_2`
where (`stu_v_2`.`sid` > 15);

