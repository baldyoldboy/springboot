create
    definer = root@localhost function fun1(n int) returns int deterministic
begin
    declare sum int default 0;
    while n>=0 do
        set sum:=sum+n;
        set n:=n-1;
    end while;

    return sum;
end;

