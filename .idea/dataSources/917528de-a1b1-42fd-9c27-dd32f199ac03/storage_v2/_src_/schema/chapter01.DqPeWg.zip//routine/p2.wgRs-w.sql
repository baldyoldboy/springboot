create
    definer = root@localhost procedure p2(INOUT score double)
begin
    set score=score*0.5;
end;

