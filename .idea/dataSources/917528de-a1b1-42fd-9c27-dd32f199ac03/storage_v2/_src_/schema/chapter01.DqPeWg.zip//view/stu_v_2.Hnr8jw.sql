create definer = root@localhost view stu_v_2 as
select `stu_v_1`.`sid` AS `sid`, `stu_v_1`.`sname` AS `sname`
from `chapter01`.`stu_v_1`
where (`stu_v_1`.`sid` > 10);

