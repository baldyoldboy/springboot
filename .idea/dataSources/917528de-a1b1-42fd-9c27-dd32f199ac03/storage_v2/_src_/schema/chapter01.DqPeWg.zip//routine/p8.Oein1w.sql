create
    definer = root@localhost procedure p8(IN n int)
begin
    declare sum int default 0;
    total:loop
        if n<=0 then
            leave total;
        end if;
        set sum:=sum+n;
        set n:=n-1;
    end loop;
    select sum;
end;

