create
    definer = root@localhost procedure p6(IN n int)
begin
    declare sum int default 0;

    while n>0 do
        set sum:= n+sum;
        set n:=n-1;
    end while;
    select sum;
end;

