create
    definer = root@localhost procedure p9(IN n int)
begin
    declare sum int default 0;
    a1:loop
        if n<=0 then
            leave a1;
        end if;

        if n%2=1 then
            set n:=n-1;
            iterate a1;
        end if;

        set sum:=sum+n;
        set n:=n-1;
    end loop;
    select sum;
end;

