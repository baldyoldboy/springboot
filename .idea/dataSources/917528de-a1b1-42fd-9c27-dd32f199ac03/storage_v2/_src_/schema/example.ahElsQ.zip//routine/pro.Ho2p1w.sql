create
    definer = root@localhost procedure pro(IN money int)
begin
    declare s_name varchar(50);
    declare s_job varchar(20);
    declare s_salary int;

    declare money_cur cursor for
        select name,job,salary from emp where emp.salary>=money;
    declare exit handler for sqlstate '02000' close money_cur;

    drop table if exists m_table;
    create table if not exists m_table(
      m_name varchar(50),
      m_job varchar(20),
      m_salary int
    );

    open money_cur;
    while true do
        fetch money_cur into s_name,s_job,s_salary ;
        insert into m_table values (s_name,s_job,s_salary);
    end while;


    close money_cur;
    select * from m_table;
end;

