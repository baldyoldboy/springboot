create definer = `mysql.sys`@localhost view version as
select '1.5.0' AS `sys_version`, version() AS `mysql_version`;

